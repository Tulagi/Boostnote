#!/bin/bash

# 依赖:
#     1. git
#     2. node
#     3. npm
#     4. hexo
#     5. hexo next theme
#
# 流程:
#     1. boostnote源文件库地址:
#         git@github.com:Tulagi/Boostnote.git
#         git@gitee.com:git_tulagi/boostnote_blog.git
#     2. 克隆 boostnote 源文件;
#     3. 将 boostnote 中的cson源文件转换成带有 front-matter 的 hexo 格式的 markdown 文件;
#     4. 删除 hexo 的发布目录(_posts)中的文件;
#     5. 将新转换的文件拷贝到 hexo 的发布目录(_posts)中;
#     6. 通过 hexo 重新编译生成静态文件并发布部署;
#     7. 码云需要手动点pages的更新,github是自动的,但是太慢了;

root=/home/hexo
hexo_root=$root/hexo_mayun
boostnote_root=$root/Boostnote2Hexo

mkdir -p $boostnote_root
cd $boostnote_root

rm -rf boostnote_blog
git clone git@gitee.com:git_tulagi/boostnote_blog.git

rm -rf output
sh cson_to_markdown.sh output boostnote_blog/Blog

rm -rf $hexo_root/source/_posts/*
cp -r output/* $hexo_root/source/_posts/

cd $hexo_root
hexo clean && hexo g && hexo d

