#!/bin/bash

# 1. boostnote源文件库地址:
#     git@github.com:Tulagi/Boostnote.git
#     git@gitee.com:git_tulagi/boostnote_blog.git
# 2. 克隆 boostnote 源文件;
# 3. 将 boostnote 中的cson源文件转换成带有 front-matter 的 hexo 格式的 markdown 文件;
#
#
#
#
#
#

root=/home/hexo
mkdir -p $root/Boostnote2Hexo/Boostnote

cd $root/Boostnote2Hexo/Boostnote
git pull origin master

cd $root/Boostnote2Hexo/
rm -rf output
sh cson_to_markdown.sh output Boostnote/Blog

rm -rf $root/hexo/source/_posts/*
cp -r $root/Boostnote2Hexo/output/* $root/hexo/source/_posts/

cd $root/hexo
hexo clean && hexo g && hexo d
