#!/bin/bash

outDir=$1
boostnote_root=$2

if [ ! -d "$outDir" ]; then
    mkdir "$outDir"
fi

for fileName in `ls ${boostnote_root}/notes/*.cson`; do

    id=`echo ${fileName} | sed -e 's%.*/\(.*\)\.cson%\1%p' | head -1`
    title=`sed -n "/^title:/p" "$fileName" | head -1 | sed -e "s/title:\s\"\(.*\)\"$/\1/"`
    date=`sed -n "/^createdAt:/p" "$fileName" | head -1 | sed -e "s/createdAt:\s\"\(.*\)T\(.*\)\..*\"$/\1 \2/"`
    tags=`sed -n "/^tags:\s\[$/,/^\]$/p" "$fileName" | sed '1d' | sed '$d' | sed 's/[ "]//g' | sed 's/^/  - /g'`
    categories=`sed -n "/^tags:\s\[$/,/^\]$/p" "$fileName" | sed '1d' | sed '$d' | sed 's/[ "]//g' | sed 's/^/  - /g' | head -1`

    file="$outDir/$title.md"
    echo "---" >> ${file}
    echo "title: ${title}" >> ${file}
    echo "categories:" >> ${file}
    echo "${categories}" >> ${file}
    echo "tags:" >> ${file}
    echo "${tags}" >> ${file}
    echo "date: ${date}" >> ${file}
    echo "---" >> ${file}
    echo -e "\n" >> ${file}
    echo "> ${title}" >> ${file}
    echo -e "\n" >> ${file}
    echo '<!-- more -->' >> ${file}
    echo -e "\n" >> ${file}

    echo "`sed -n "/^content:\s'''$/,/^'''$/p" $fileName | sed '1d' | sed '$d' | cut -b 3-`" >> ${file}

    sed -i 's/\\\\/\\/g' ${file}
    sed -i "s%:storage\\\\.*\\\\\(.*\)%${title}/\1%g" ${file}

    attachments_dir=$boostnote_root/attachments/$id
    [ -d $attachments_dir ] && mkdir -p $outDir/$title/ && cp -r $attachments_dir/* $outDir/$title/

    echo "$title.md file created."
done

