---
title: git操作记录
categories:
  - git
tags:
  - git
date: 2018-12-02 13:44:54
---


> git操作记录


<!-- more -->


# git操作记录

### 删除远端分支
```
git push origin :branch
git push origin --delete branch
```
