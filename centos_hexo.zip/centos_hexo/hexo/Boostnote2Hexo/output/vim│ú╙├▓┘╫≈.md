---
title: vim常用操作
categories:
  - vim
tags:
  - vim
date: 2018-12-02 16:22:32
---


> vim常用操作


<!-- more -->


# vim常用操作

> VIM常用操作记录

<!-- more -->

### 跳转到指定行
```
行号 + gg
:行号 + Enter
```

### 设置原样粘贴，不会自动缩进
```
set paste
```
