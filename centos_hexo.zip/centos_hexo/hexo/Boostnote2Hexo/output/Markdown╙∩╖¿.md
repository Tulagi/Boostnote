---
title: Markdown语法
categories:
  - markdown
tags:
  - markdown
date: 2019-08-24 02:06:26
---


> Markdown语法


<!-- more -->


# Markdown语法

### 折叠长句

<details><summary>Boostnote是对应markdown记法的记事本，信息排序・共享的一种工具。</summary>
- Features - <br>
· Search function to find memos in one shot
· Supports markdown notation <br>
· Support for Mac, Windows, Linux, iOS, Android <br>
· Export and import to Plain text (.txt), Markdown (.md) format <br>
· Supports PDF saving <br>
· Can be used offline <br>
· Synchronize to dropbox etc. with setting <br>
· Supports theme colors and numerous fonts <br>
</details>
