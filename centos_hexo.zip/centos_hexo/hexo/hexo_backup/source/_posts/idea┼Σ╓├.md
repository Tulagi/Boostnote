---
title: idea配置
categories:
  - idea
tags:
  - idea
date: 2018-11-11 08:47:02
---

> 记录idea系配置

<!-- more -->

# 配置集

### 配置页面(以下配置无特殊说明均是该页面)
```
菜单路径: File -> Settings
快捷键: Ctrl + Alt + S
```

### 修改字体大小
```
Editor -> Font
等宽字体: Courier New
```

### 字体大小滚轮调节
```
Editor -> General -> Change font size (Zoom) with Ctrl+Mouse Wheel
```
