---
title: software
categories:
  - 软件
tags:
  - 软件
date: 2018-11-07 07:25:09
---

> 记录窗口下那些用过的软件。

<!-- more -->

# 软件集合
* 编辑器
    * notepad++
    > 文本编辑器，各种插件，可深度定制；

    * gvim
    > 好用
    
    * vscode
    > windwos推出的诚意之作

    * Atom
    > github出品

* 浏览器
    * chrome
    > google

    * firefox
    > 

* ide
    * JetBrains CLion
    > c编辑器

    * Source Insight
    > c编辑器

    * Intellij IDEA
    > java编辑器

    * JetBrains PyCharm
    > python编辑器

* 流程图
    * visio
    > 

    * EA (Enterprise Architect)
    > 

* Markdown
    * Typora
    > 

    * Markdown Pad
    > 

* 效率工具
    * snipaste
    > 截图工具

    * Everything
    > 搜索工具

    * WGestures
    > 鼠标手势工具

    * autohotkey
    > 自定义工具

    * capslock++
    > 自定义capslock工具

    * beyondcompare
    > 文本文件夹对比工具

    * clover
    > windows文件夹整合工具

    * ConEmu
    > windows cmd 替代工具

    * cmder
    > 封装ConEmu

    * MDIE
    > 多窗口

    * Q-Dir
    > 多窗口

    * Total Command
    >

    * FileLocator
    > 文件文本搜索工具

* SSH工具
    * putty
    > 

    * xshell
    > 

* FTP工具
    * xftp
    > 

    * filezilla
    > 

    * xlight
    > 

    * winscp
    >

* 虚拟化
    * VirtualBox
    > 
    
    * VMware
    > 

* 通讯工具
    * TIM
    > 

    * QQ
    > 

    * 钉钉
    > 

    * 飞鸽
    >  

* 笔记工具
    * boogu
    > 树形

    * onenote
    > office

    * ediary
    > 

    * 为知 (wiz)
    > 收费了

    * keynote
    > 

* 播放器
    * vlc
    > 

    * kmplayer
    > 

* 思维导图
    * xmind
    > 

    * MindManager
    > 

* 网络工具
    * Fiddler
    > 抓包工具

* 代码管理
    * git
    > 

    * svn
    > 

* 下载软件
    * 迅雷
    >

    * utorrent
    > 
