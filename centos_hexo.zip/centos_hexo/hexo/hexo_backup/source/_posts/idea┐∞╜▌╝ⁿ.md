---
title: idea快捷键
categories:
  - idea
tags:
  - idea 快捷键
date: 2018-11-11 09:04:01
---

> 记录idea系ide的快捷键

<!-- more -->

# 快捷键集

### 快捷键基于Default修改
```
Keymap -> Duplicate -> Default copy for me
```

### 搜索
```
Ctrl + Shift + F
```
