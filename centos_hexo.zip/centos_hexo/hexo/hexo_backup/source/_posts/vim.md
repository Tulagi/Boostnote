---
title: vim常用操作
categories:
  - vim
tags:
  - vim
date: 2018-11-07 07:23:29
---

> VIM常用操作记录

<!-- more -->

# VIM操作小结

* 跳转到指定行
```
行号 + gg
:行号 + Enter
```
