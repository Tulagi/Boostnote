---
title: git cli 命令记录
categories:
  - git
tags:
  - git
  - cli
date: 2018-12-02 23:48:58
---

> git命令备忘录

<!-- more -->

### 删除远端分支
```
git push origin :branch
git push origin --delete branch
```

