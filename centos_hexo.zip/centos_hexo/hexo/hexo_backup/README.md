hexo branch for hexo
1. install git
2. install nodejs
3. install hexo
4. install next theme
5. install hexo-generator-searchdb plugin
