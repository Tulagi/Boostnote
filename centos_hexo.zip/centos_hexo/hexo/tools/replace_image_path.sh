#!/bin/bash

# 替换md文件中的图片路径为title

